# Character AI Chat Application

A modern, responsive web application that replicates a character AI chat interface with multiple screens and features.

## Features

### Implemented Screens

1. **Chat List (Home)**
   - Search bar for finding characters
   - List of active conversations with avatars, names, and message previews
   - Timestamps for each conversation
   - Clickable chat items to open conversations

2. **Explore**
   - Tab navigation (Subscriptions/Explore)
   - Horizontal scrollable category tabs (Fantastic, Multi-Role, Undercover Love, OC, Anime)
   - 2-column grid of character cards
   - Character cards with images, descriptions, tags, and message counts
   - "New" badges and multi-role indicators

3. **Character Profile**
   - Large character hero image
   - Character information (name, ID, creator)
   - Description and personality tags
   - Statistics (collectors, messages)
   - Action buttons (Chat, Favorite, Share)
   - Comments section with user interactions

4. **Chat Interface**
   - Character-specific chat header
   - AI-generated disclaimer banner
   - Character introduction card
   - Message bubbles with timestamps
   - "Free" badges on messages
   - Input area with attachment and send buttons

5. **Create Modal**
   - Character creation options (Regular, Multi-Role)
   - Templates section
   - Story creation (Fiction)
   - Canvas section (AvatarMix)
   - Gradient card designs

6. **Coins/Store**
   - Coin balance display
   - Coins description with features
   - Earning options (Watch AD, Daily Tasks)
   - Purchase options grid with pricing
   - Special offers with timers
   - Footer with policy links

7. **Sidebar Navigation**
   - Following, Top Creators, You, For you
   - Profile, Chats, Characters, Gallery
   - Favorites, Coins, Membership
   - Create, Install our app

8. **Bottom Navigation (Mobile)**
   - Home, Messages (with notification badge)
   - Create (center button)
   - Explore, Profile

## Design System

### Color Palette
- **Background**: Pure black (#000000)
- **Cards/Panels**: Dark gray (#1a1a1a, #2a2a2a)
- **Primary Accent**: Purple/Blue gradient
- **Secondary Accent**: Teal/Cyan
- **Highlight**: Gold/Yellow for character names
- **Text**: White (primary), Gray (secondary)

### Typography
- Clean, modern sans-serif font
- Bold headers and titles
- Italic text for narrative/actions in chat
- Color-coded character names in gold/yellow

### Components
- Rounded corners on all interactive elements
- Gradient backgrounds for feature cards
- Badge indicators (NEW, PRO, notification counts)
- Smooth hover states and transitions
- Responsive grid layouts

## Technology Stack

- **Framework**: React 18
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Routing**: React Router DOM
- **UI Components**: shadcn/ui
- **Animations**: Framer Motion

## Project Structure

```
character-ai-app/
├── src/
│   ├── assets/          # Images and static files
│   ├── components/
│   │   └── ui/          # shadcn/ui components
│   ├── App.jsx          # Main application component
│   ├── App.css          # Global styles
│   ├── main.jsx         # Entry point
│   └── index.css        # Base styles
├── public/              # Public assets
├── dist/                # Production build
└── package.json         # Dependencies
```

## Getting Started

### Prerequisites
- Node.js 18+ 
- pnpm (or npm/yarn)

### Installation

1. Navigate to the project directory:
```bash
cd character-ai-app
```

2. Install dependencies:
```bash
pnpm install
```

3. Start the development server:
```bash
pnpm run dev
```

4. Open your browser and visit:
```
http://localhost:5173
```

### Building for Production

```bash
pnpm run build
```

The production-ready files will be in the `dist/` directory.

## Features Breakdown

### Responsive Design
- Desktop: Sidebar navigation always visible
- Mobile: Bottom navigation with hamburger menu for sidebar
- Adaptive layouts for all screen sizes

### Interactive Elements
- Clickable chat items navigate to chat screens
- Character cards link to profile pages
- Sidebar menu items navigate between sections
- Bottom navigation for quick access on mobile

### Visual Polish
- Smooth transitions and hover effects
- Gradient backgrounds for premium features
- Badge indicators for new content and notifications
- Color-coded UI elements for better UX

## Screens Navigation

- `/` - Chat List (Home)
- `/explore` - Explore characters
- `/character/:id` - Character profile
- `/chat/:id` - Chat with character
- `/create` - Create new content
- `/coins` - Coins store
- `/profile` - User profile
- `/following` - Following feed
- `/favorites` - Favorite characters
- And more...

## Customization

The application uses Tailwind CSS for styling, making it easy to customize colors, spacing, and other design elements. Key customization points:

1. **Colors**: Modify the color palette in `App.css`
2. **Layout**: Adjust grid and flex layouts in component files
3. **Components**: Add or modify UI components in `src/components/ui/`

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Notes

- This is a UI-only implementation without backend functionality
- All data is mock data for demonstration purposes
- The application is fully responsive and mobile-friendly
- Character images use placeholder gradients

## Future Enhancements

- Backend API integration
- Real-time chat functionality
- User authentication
- Character creation workflow
- Payment processing for coins
- Push notifications
- Progressive Web App (PWA) support
- Native mobile app with Capacitor

## License

This project is for demonstration purposes.

