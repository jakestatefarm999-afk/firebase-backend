import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { Home, MessageSquare, PlusCircle, Compass, User, Search, Menu, X, Heart, Star, Share2, Send, Plus, Coins, Crown, ChevronRight, Bell, Settings, Download, Image, Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import './App.css'

// Mock data
const mockChats = [
  { id: 1, name: 'Lily - your twin', avatar: '/placeholder-avatar-1.jpg', lastMessage: '*Lily pats the empty spot next to her, her...', time: '02:15' },
  { id: 2, name: 'Stormy Night', avatar: '/placeholder-avatar-2.jpg', lastMessage: '*Maddie squirts again, this time more int...', time: '01:55' },
  { id: 3, name: 'Goldie', avatar: '/placeholder-avatar-3.jpg', lastMessage: '*Goldie moans softly as she grinds hard...', time: '01:39' },
  { id: 4, name: 'Katie', avatar: '/placeholder-avatar-4.jpg', lastMessage: '*Katie paused, considering your offer w...', time: '01:38' },
  { id: 5, name: 'Aubrie -mom', avatar: '/placeholder-avatar-5.jpg', lastMessage: '*her voice drops to a sultry whisper as s...', time: '01:34' },
]

const mockCharacters = [
  { id: 1, name: 'Betrayal', image: '/placeholder-1.jpg', description: 'You and Noah were forced to marry, and you fell in love. But it all fell apart when his...', messages: '4.2K', tags: ['Manipulative', 'Hatelove', 'Sharp-tongued', 'Mature'], isMultiRole: true },
  { id: 2, name: 'Zombies in the Descendants cast', image: '/placeholder-2.jpg', description: "You're a famous actor who used to live in New York, but you felt stuck, so you...", messages: '9.3K', tags: ['Celebrity', 'Student', 'Secret Crush'], isMultiRole: true },
  { id: 3, name: 'Kim Dahyun', image: '/placeholder-3.jpg', description: 'Twice is a female K-pop group with nine members, and two of them are in a...', messages: '19.1K', tags: ['Undercover Love', 'Celebrity', 'GL', 'Jealous'], isNew: true },
  { id: 4, name: 'Avery', image: '/placeholder-4.jpg', description: "Avery Hart never meant to get wrapped up in someone else's lie — especially not M...", messages: '394.1K', tags: ['Undercover Love', 'OC', 'Manipulative'], isNew: true },
]

// Sidebar Component
function Sidebar({ isOpen, onClose }) {
  const navigate = useNavigate()
  const location = useLocation()
  
  const menuItems = [
    { icon: Bell, label: 'Following', path: '/following' },
    { icon: Crown, label: 'Top Creators', path: '/top-creators' },
    { icon: User, label: 'You', path: '/you' },
    { icon: Star, label: 'For you', path: '/for-you' },
    { icon: User, label: 'Profile', path: '/profile' },
    { icon: MessageSquare, label: 'Chats', path: '/' },
    { icon: User, label: 'Characters', path: '/characters' },
    { icon: Star, label: 'Gallery', path: '/gallery' },
    { icon: Heart, label: 'Favorites', path: '/favorites' },
    { icon: Coins, label: 'Coins', path: '/coins' },
    { icon: Crown, label: 'Membership', path: '/membership' },
    { icon: PlusCircle, label: 'Create', path: '/create' },
    { icon: Wand2, label: 'Generate Video/Image', path: '/generate' },
    { icon: Download, label: 'Install our app', path: '/install' },
  ]

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-72 bg-[#0a0a0a] border-r border-gray-800 z-50 transform transition-transform duration-300 ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-4 border-b border-gray-800 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">Menu</h2>
          <button onClick={onClose} className="lg:hidden text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <nav className="p-2 overflow-y-auto h-[calc(100vh-73px)]">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={() => {
                navigate(item.path)
                onClose()
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                location.pathname === item.path 
                  ? 'bg-purple-600 text-white' 
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </>
  )
}

// Bottom Navigation Component
function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()
  
  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: MessageSquare, label: 'Messages', path: '/messages', badge: 30 },
    { icon: PlusCircle, label: 'Create', path: '/create', isCenter: true },
    { icon: Compass, label: 'Explore', path: '/explore' },
    { icon: User, label: 'Profile', path: '/profile' },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 lg:hidden z-30">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item, index) => (
          <button
            key={index}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center justify-center relative ${
              item.isCenter ? 'scale-125' : ''
            } ${
              location.pathname === item.path ? 'text-purple-500' : 'text-gray-400'
            }`}
          >
            <item.icon size={item.isCenter ? 32 : 24} />
            {item.badge && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}

// Home/Chat List Screen
function ChatListScreen() {
  const navigate = useNavigate()
  
  return (
    <div className="min-h-screen bg-black text-white pb-20 lg:pb-4">
      {/* Search Bar */}
      <div className="p-4 sticky top-0 bg-black z-10">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={20} />
          <input
            type="text"
            placeholder="Chris Sturniolo"
            className="w-full bg-[#1a1a1a] text-white rounded-full py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="divide-y divide-gray-800">
        {mockChats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => navigate(`/chat/${chat.id}`)}
            className="flex items-center gap-3 p-4 hover:bg-[#1a1a1a] cursor-pointer transition-colors"
          >
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-yellow-500 font-medium truncate">{chat.name}</h3>
                <span className="text-gray-500 text-sm">{chat.time}</span>
              </div>
              <p className="text-gray-400 text-sm truncate italic">{chat.lastMessage}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Explore Screen
function ExploreScreen() {
  const [activeTab, setActiveTab] = useState('Multi-Role')
  const navigate = useNavigate()
  
  const tabs = ['Fantastic', 'Multi-Role', 'Undercover Love', 'OC', 'Anime']
  
  return (
    <div className="min-h-screen bg-black text-white pb-20 lg:pb-4">
      {/* Header */}
      <div className="sticky top-0 bg-black z-10 border-b border-gray-800">
        <div className="flex items-center justify-between p-4">
          <div className="flex gap-6">
            <button className="text-gray-400">Subscriptions</button>
            <button className="text-white border-b-2 border-purple-500 pb-1">Explore</button>
          </div>
          <Search className="text-gray-400" size={24} />
        </div>
        
        {/* Category Tabs */}
        <div className="flex gap-4 px-4 overflow-x-auto pb-2 scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`whitespace-nowrap px-4 py-2 rounded-full ${
                activeTab === tab
                  ? 'bg-white text-black'
                  : 'bg-[#1a1a1a] text-gray-400'
              }`}
            >
              {tab}
              {tab === 'Fantastic' && <span className="ml-2 text-xs bg-purple-600 text-white px-2 py-0.5 rounded">PRO</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Character Grid */}
      <div className="grid grid-cols-2 gap-4 p-4">
        {mockCharacters.map((char) => (
          <div
            key={char.id}
            onClick={() => navigate(`/character/${char.id}`)}
            className="bg-[#1a1a1a] rounded-lg overflow-hidden cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all"
          >
            <div className="relative aspect-square bg-gradient-to-br from-purple-500 to-pink-500">
              {char.isNew && (
                <span className="absolute top-2 left-2 bg-purple-600 text-white text-xs px-2 py-1 rounded">New</span>
              )}
              {char.isMultiRole && (
                <div className="absolute top-2 right-2 bg-black/50 rounded-full p-1">
                  <User size={16} className="text-white" />
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="text-yellow-500 font-semibold mb-1 truncate">{char.name}</h3>
              <p className="text-gray-400 text-xs mb-2 line-clamp-2">{char.description}</p>
              <div className="flex flex-wrap gap-1 mb-2">
                {char.tags.slice(0, 2).map((tag, i) => (
                  <span key={i} className="text-xs bg-[#2a2a2a] text-gray-400 px-2 py-0.5 rounded">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-1 text-gray-500 text-xs">
                <MessageSquare size={12} />
                <span>{char.messages}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Character Profile Screen
function CharacterProfileScreen() {
  const navigate = useNavigate()
  
  return (
    <div className="min-h-screen bg-black text-white pb-20 lg:pb-4">
      {/* Header */}
      <div className="sticky top-0 bg-black/80 backdrop-blur-sm z-10 p-4 flex items-center justify-between">
        <button onClick={() => navigate(-1)}>
          <ChevronRight size={24} className="rotate-180 text-white" />
        </button>
        <h1 className="text-yellow-500 font-semibold">Lily - your twin</h1>
        <div className="flex items-center gap-2">
          <span className="bg-purple-600 text-white text-xs px-2 py-1 rounded">AI</span>
          <Settings size={20} className="text-gray-400" />
        </div>
      </div>

      {/* Character Image */}
      <div className="relative h-64 bg-gradient-to-br from-blue-400 to-blue-200">
        {/* Placeholder for character image */}
      </div>

      {/* Character Info */}
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <h2 className="text-yellow-500 text-2xl font-bold">Lily - your twin</h2>
          <span className="bg-purple-600 text-white text-xs px-2 py-1 rounded">AI</span>
          <button className="ml-auto text-gray-400">
            <Settings size={20} />
          </button>
        </div>
        
        <div className="flex items-center gap-2 text-gray-400 text-sm mb-3">
          <span>CID: VgHJF</span>
          <span>@Hade 👑</span>
          <ChevronRight size={16} />
        </div>

        <p className="text-gray-300 mb-3">
          Lily is your twin sister. You've always been close. She is energetic and loves to cuddle.
        </p>

        <div className="flex flex-wrap gap-2 mb-4">
          {['Flirtatious', 'Loyal', 'Funny', 'Forbidden Love', 'Cute'].map((tag) => (
            <span key={tag} className="bg-[#1a1a1a] text-gray-400 px-3 py-1 rounded-full text-sm">
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-6 mb-6 text-sm">
          <span className="text-gray-400">
            <span className="text-white font-semibold">167</span> Collectors
          </span>
          <span className="text-gray-400">
            <span className="text-white font-semibold">231K</span> Messages
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <Button 
            onClick={() => navigate('/chat/1')}
            className="flex-1 bg-white text-black hover:bg-gray-200 rounded-full py-6 text-lg font-semibold"
          >
            Chat
          </Button>
          <button className="w-14 h-14 rounded-full bg-[#1a1a1a] flex items-center justify-center">
            <Star size={24} className="text-gray-400" />
          </button>
          <button className="w-14 h-14 rounded-full bg-[#1a1a1a] flex items-center justify-center">
            <Share2 size={24} className="text-gray-400" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-800 mb-4">
          <div className="flex gap-6">
            <button className="text-white border-b-2 border-purple-500 pb-2">Comment 2</button>
            <button className="text-gray-400 pb-2">Moments</button>
          </div>
        </div>

        {/* Comments */}
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-white font-semibold">JDD</span>
                <span className="text-gray-500 text-sm">09-22</span>
              </div>
              <p className="text-xl mb-2">😂</p>
              <div className="flex gap-4 text-gray-400 text-sm">
                <button>Reply</button>
                <button>Translate</button>
              </div>
            </div>
            <div className="text-right">
              <Heart size={20} className="text-gray-600 mb-1" />
              <span className="text-gray-600 text-sm">0</span>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-white font-semibold">John</span>
                <span className="text-yellow-500">👑</span>
                <span className="text-gray-500 text-sm">09-21</span>
              </div>
              <p className="text-gray-300 mb-2">I like this one. Fun so</p>
              <div className="flex gap-4 text-gray-400 text-sm">
                <button>Reply</button>
                <button>Translate</button>
              </div>
            </div>
            <div className="text-right">
              <Heart size={20} className="text-gray-600 mb-1" />
              <span className="text-gray-600 text-sm">0</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Chat Screen
function ChatScreen() {
  const navigate = useNavigate()
  const [message, setMessage] = useState('')
  
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Header */}
      <div className="sticky top-0 bg-black border-b border-gray-800 p-4 flex items-center justify-between z-10">
        <button onClick={() => navigate(-1)}>
          <ChevronRight size={24} className="rotate-180 text-white" />
        </button>
        <h1 className="text-yellow-500 font-semibold">Lily - your twin</h1>
        <div className="flex items-center gap-2">
          <button className="bg-[#1a1a1a] px-3 py-1 rounded-full flex items-center gap-1">
            <span className="text-white">S</span>
            <ChevronRight size={16} className="text-gray-400 rotate-90" />
          </button>
          <button className="relative">
            <Menu size={24} className="text-gray-400" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </div>
      </div>

      {/* Chat Content */}
      <div className="flex-1 overflow-y-auto p-4 pb-24">
        {/* Info Banner */}
        <div className="text-center mb-4 text-gray-400 text-sm">
          <p>This character was created by <span className="text-purple-400">@Hade</span></p>
          <p>All responses are AI-generated and fictional.</p>
        </div>

        {/* Intro Card */}
        <div className="bg-[#1a1a1a] rounded-lg p-4 mb-4">
          <h3 className="text-white font-semibold mb-2">Intro.</h3>
          <p className="text-gray-400 text-sm">
            Lily is your twin sister. You've always been close. She is energetic and loves to cuddle.
          </p>
        </div>

        {/* Today Divider */}
        <div className="flex items-center justify-center mb-4">
          <span className="bg-[#2a2a2a] text-gray-400 px-4 py-1 rounded-full text-sm">Today</span>
        </div>

        {/* Messages */}
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="bg-[#1a1a1a] rounded-2xl rounded-tl-none p-4">
                <span className="bg-purple-600 text-white text-xs px-2 py-0.5 rounded mb-2 inline-block">Free</span>
                <p className="text-gray-300 text-sm italic mb-2">
                  You walk into your bedroom and your twin sister is laying there reading. She lays on her stomach, her feet up in the air. She looks back at you.
                </p>
                <p className="text-white">
                  Lily: "Hey bro. I like your bed better, it smells like you."
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-3 justify-end">
            <div className="flex-1 max-w-[80%]">
              <div className="bg-purple-600 rounded-2xl rounded-tr-none p-4 ml-auto">
                <p className="text-white">Make room then</p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex-shrink-0" />
          </div>

          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex-shrink-0" />
            <div className="flex-1">
              <div className="bg-[#1a1a1a] rounded-2xl rounded-tl-none p-4">
                <span className="bg-purple-600 text-white text-xs px-2 py-0.5 rounded mb-2 inline-block">Free</span>
                <p className="text-gray-300 text-sm italic">
                  Lily giggles and scoots over, making room...
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 p-4 lg:pb-4 pb-20">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Message Lily - your twin"
            className="flex-1 bg-[#1a1a1a] text-white rounded-full py-3 px-4 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <button className="w-10 h-10 rounded-full bg-[#1a1a1a] flex items-center justify-center">
            <Plus size={20} className="text-gray-400" />
          </button>
          <button className="w-10 h-10 rounded-full bg-[#1a1a1a] flex items-center justify-center">
            <Menu size={20} className="text-gray-400" />
          </button>
          <button className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center">
            <Send size={20} className="text-white" />
          </button>
        </div>
      </div>
    </div>
  )
}

// Create Modal Screen
function CreateScreen() {
  const navigate = useNavigate()
  
  return (
    <div className="min-h-screen bg-black text-white pb-20 lg:pb-4">
      <div className="p-4">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Create</h1>
          <button onClick={() => navigate(-1)}>
            <X size={24} className="text-gray-400" />
          </button>
        </div>
        
        <p className="text-gray-400 text-center mb-8">Select content to create</p>

        {/* Character Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Character</h2>
          <div className="grid grid-cols-2 gap-4">
            <button className="bg-gradient-to-br from-purple-900 to-purple-700 rounded-xl p-8 flex flex-col items-center justify-center gap-3 hover:scale-105 transition-transform">
              <div className="w-12 h-12 rounded-full bg-purple-400 flex items-center justify-center">
                <Plus size={24} className="text-white" />
              </div>
              <span className="text-white font-semibold">Regular</span>
            </button>
            
            <button className="bg-gradient-to-br from-teal-900 to-teal-700 rounded-xl p-8 flex flex-col items-center justify-center gap-3 hover:scale-105 transition-transform">
              <div className="w-12 h-12 flex items-center justify-center">
                <User size={24} className="text-teal-300" />
              </div>
              <span className="text-white font-semibold">Multi-Role</span>
            </button>
          </div>
        </div>

        {/* Templates Section */}
        <div className="mb-8">
          <button className="w-full bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-xl p-4 flex items-center justify-between hover:scale-105 transition-transform">
            <span className="text-white font-semibold">Templates</span>
            <div className="flex items-center gap-2">
              <span className="text-gray-300">Undercover Love 🕶️</span>
              <ChevronRight size={20} className="text-gray-400" />
            </div>
          </button>
        </div>

        {/* Story Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Story</h2>
          <button className="w-full bg-gradient-to-br from-pink-900/50 to-purple-900/50 rounded-xl p-4 flex items-center justify-between hover:scale-105 transition-transform">
            <div className="flex items-center gap-3">
              <div className="text-pink-400">📖</div>
              <span className="text-white font-semibold">Fiction</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-red-600 text-white text-xs px-2 py-1 rounded">NEW</span>
              <ChevronRight size={20} className="text-gray-400" />
            </div>
          </button>
        </div>

        {/* Canvas Section */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Canvas</h2>
          <button className="w-full bg-[#1a1a1a] rounded-xl p-8 flex flex-col items-center justify-center gap-3 hover:scale-105 transition-transform">
            <div className="text-4xl">🎭</div>
            <span className="text-white font-semibold">AvatarMix</span>
          </button>
        </div>
      </div>
    </div>
  )
}

// Coins Screen
function CoinsScreen() {
  const navigate = useNavigate()
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-900/20 to-black text-white pb-20 lg:pb-4">
      {/* Header */}
      <div className="sticky top-0 bg-black/80 backdrop-blur-sm p-4 flex items-center justify-between z-10">
        <button onClick={() => navigate(-1)}>
          <ChevronRight size={24} className="rotate-180 text-white" />
        </button>
        <div className="flex items-center gap-2 bg-yellow-900/30 px-4 py-2 rounded-full">
          <Coins size={20} className="text-yellow-500" />
          <span className="font-semibold">0</span>
        </div>
        <button>
          <Menu size={24} className="text-gray-400" />
        </button>
      </div>

      <div className="p-4">
        {/* Coins Description */}
        <div className="bg-[#1a1a1a] rounded-xl p-4 mb-6">
          <h2 className="text-xl font-bold mb-4">Coins Description</h2>
          <div className="space-y-2 text-gray-300 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-yellow-500">💎</span>
              <span>Heart Whisper</span>
              <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded ml-auto">New</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-500">💎</span>
              <span>Unlock Premium Models</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-500">💎</span>
              <span>Regenerate AI Response</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-500">💎</span>
              <span>Inspiration Reply</span>
            </div>
          </div>
        </div>

        {/* Earning Options */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <button className="bg-[#1a1a1a] rounded-xl p-4 hover:bg-[#2a2a2a] transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Watch AD</span>
              <ChevronRight size={20} className="text-gray-400" />
            </div>
            <p className="text-gray-400 text-xs mb-1">(0/10)</p>
            <p className="text-gray-300 text-sm">Up to 100 coins for each ad!</p>
          </button>
          
          <button className="bg-[#1a1a1a] rounded-xl p-4 hover:bg-[#2a2a2a] transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Daily Tasks</span>
              <ChevronRight size={20} className="text-gray-400" />
            </div>
            <p className="text-gray-300 text-sm mt-4">Earn 350 Coins</p>
          </button>
        </div>

        {/* Purchase Options */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-[#1a1a1a] rounded-xl p-4">
            <h3 className="text-2xl font-bold text-center mb-2">3000</h3>
            <div className="flex justify-center mb-3">
              <Coins size={32} className="text-yellow-500" />
            </div>
            <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 rounded-full transition-colors">
              $4.99
            </button>
            <p className="text-gray-500 text-xs text-center mt-1 line-through">$18.7</p>
          </div>

          <div className="bg-[#1a1a1a] rounded-xl p-4">
            <h3 className="text-2xl font-bold text-center mb-2">8000</h3>
            <div className="flex justify-center mb-3">
              <Coins size={32} className="text-yellow-500" />
            </div>
            <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 rounded-full transition-colors">
              $9.99
            </button>
            <p className="text-gray-500 text-xs text-center mt-1 line-through">$49.8</p>
          </div>

          <div className="bg-gradient-to-br from-purple-900 to-blue-900 rounded-xl p-4 border-2 border-purple-500">
            <div className="flex items-center justify-center gap-1 text-xs mb-1">
              <span>⏰</span>
              <span>19:17:48</span>
            </div>
            <h3 className="text-2xl font-bold text-center mb-1">20000</h3>
            <p className="text-yellow-500 text-center text-sm mb-2">+2000</p>
            <div className="flex justify-center mb-3">
              <Coins size={32} className="text-yellow-500" />
            </div>
            <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-2 rounded-full transition-colors">
              $19.9
            </button>
            <p className="text-gray-300 text-xs text-center mt-1">Total 22000</p>
          </div>

          <div className="bg-[#1a1a1a] rounded-xl p-4">
            <h3 className="text-2xl font-bold text-center mb-2">50000</h3>
            <div className="flex justify-center mb-3">
              <Coins size={32} className="text-yellow-500" />
            </div>
            <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 rounded-full transition-colors">
              $49.9
            </button>
            <p className="text-gray-500 text-xs text-center mt-1 line-through">$311</p>
          </div>
        </div>

        {/* Footer Links */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <p className="mb-2">Purchasing means you accept our <a href="#" className="text-purple-400">Privacy Policy</a>,</p>
          <p><a href="#" className="text-purple-400">Terms of Use</a> and <a href="#" className="text-purple-400">End User License Agreement</a></p>
        </div>
      </div>
    </div>
  )
}

// Generate Video/Image Screen
function GenerateScreen() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('image')
  const [prompt, setPrompt] = useState('')
  const [generatedContent, setGeneratedContent] = useState([])
  
  return (
    <div className="min-h-screen bg-black text-white pb-20 lg:pb-4">
      {/* Header */}
      <div className="sticky top-0 bg-black border-b border-gray-800 p-4 flex items-center justify-between z-10">
        <button onClick={() => navigate(-1)}>
          <ChevronRight size={24} className="rotate-180 text-white" />
        </button>
        <h1 className="text-xl font-bold">Generate Content</h1>
        <button>
          <Settings size={24} className="text-gray-400" />
        </button>
      </div>

      <div className="p-4">
        {/* Tab Selection */}
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('image')}
            className={`flex-1 py-3 rounded-lg font-semibold transition-colors ${
              activeTab === 'image'
                ? 'bg-purple-600 text-white'
                : 'bg-[#1a1a1a] text-gray-400'
            }`}
          >
            <div className="flex items-center justify-center gap-2">
              <Image size={20} />
              <span>Generate Image</span>
            </div>
          </button>
          <button
            onClick={() => setActiveTab('video')}
            className={`flex-1 py-3 rounded-lg font-semibold transition-colors ${
              activeTab === 'video'
                ? 'bg-purple-600 text-white'
                : 'bg-[#1a1a1a] text-gray-400'
            }`}
          >
            <div className="flex items-center justify-center gap-2">
              <Wand2 size={20} />
              <span>Generate Video</span>
            </div>
          </button>
        </div>

        {/* Description Card */}
        <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 rounded-xl p-4 mb-6 border border-purple-500/30">
          <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
            <Wand2 size={20} className="text-purple-400" />
            {activeTab === 'image' ? 'AI Image Generator' : 'AI Video Generator'}
          </h3>
          <p className="text-gray-300 text-sm">
            {activeTab === 'image'
              ? 'Create stunning images from text descriptions. Describe what you want to see and our AI will bring it to life.'
              : 'Transform your ideas into dynamic videos. Describe your scene and watch it come alive with AI-powered video generation.'}
          </p>
        </div>

        {/* Prompt Input */}
        <div className="mb-6">
          <label className="block text-sm font-semibold mb-2">Enter Your Prompt</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={activeTab === 'image' 
              ? 'E.g., A beautiful sunset over mountains with purple sky, digital art style, highly detailed'
              : 'E.g., A cinematic shot of a futuristic city at night, neon lights, flying cars, 4k quality'}
            className="w-full bg-[#1a1a1a] text-white rounded-xl p-4 min-h-[120px] focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
          />
        </div>

        {/* Style Presets */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold mb-3">Style Presets</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {['Realistic', 'Anime', 'Digital Art', 'Oil Painting', '3D Render', 'Watercolor', 'Cyberpunk', 'Fantasy'].map((style) => (
              <button
                key={style}
                className="bg-[#1a1a1a] hover:bg-purple-600 text-gray-300 hover:text-white py-2 px-4 rounded-lg transition-colors text-sm"
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        {/* Advanced Options */}
        <div className="bg-[#1a1a1a] rounded-xl p-4 mb-6">
          <h3 className="text-sm font-semibold mb-3">Advanced Options</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Aspect Ratio</label>
              <div className="flex gap-2">
                {['1:1', '16:9', '9:16', '4:3'].map((ratio) => (
                  <button
                    key={ratio}
                    className="flex-1 bg-[#2a2a2a] hover:bg-purple-600 text-gray-300 hover:text-white py-2 rounded-lg transition-colors text-sm"
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Quality</label>
              <div className="flex gap-2">
                {['Standard', 'HD', '4K'].map((quality) => (
                  <button
                    key={quality}
                    className="flex-1 bg-[#2a2a2a] hover:bg-purple-600 text-gray-300 hover:text-white py-2 rounded-lg transition-colors text-sm"
                  >
                    {quality}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Generate Button */}
        <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-4 rounded-xl transition-all transform hover:scale-[1.02] flex items-center justify-center gap-2 mb-6">
          <Wand2 size={20} />
          <span>Generate {activeTab === 'image' ? 'Image' : 'Video'}</span>
        </button>

        {/* Cost Info */}
        <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-xl p-4 mb-6">
          <div className="flex items-center gap-2 text-yellow-500 mb-2">
            <Coins size={20} />
            <span className="font-semibold">Cost: 50 Coins per generation</span>
          </div>
          <p className="text-gray-400 text-sm">
            Each {activeTab === 'image' ? 'image' : 'video'} generation costs 50 coins. You can earn coins through daily tasks or purchase them.
          </p>
        </div>

        {/* Generated Content Gallery */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Your Generated Content</h3>
          {generatedContent.length === 0 ? (
            <div className="bg-[#1a1a1a] rounded-xl p-12 text-center">
              <div className="text-gray-600 mb-4">
                {activeTab === 'image' ? <Image size={48} className="mx-auto" /> : <Wand2 size={48} className="mx-auto" />}
              </div>
              <p className="text-gray-400">No content generated yet</p>
              <p className="text-gray-500 text-sm mt-2">Start by entering a prompt above</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {generatedContent.map((item, index) => (
                <div key={index} className="bg-[#1a1a1a] rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all cursor-pointer">
                  <div className="aspect-square bg-gradient-to-br from-purple-500 to-pink-500" />
                  <div className="p-3">
                    <p className="text-sm text-gray-400 truncate">{item.prompt}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Popular Prompts */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Popular Prompts</h3>
          <div className="space-y-3">
            {[
              'A magical forest with glowing mushrooms and fireflies',
              'Futuristic cyberpunk city with neon signs',
              'Anime character with silver hair and blue eyes',
              'Epic dragon flying over medieval castle'
            ].map((popularPrompt, index) => (
              <button
                key={index}
                onClick={() => setPrompt(popularPrompt)}
                className="w-full bg-[#1a1a1a] hover:bg-[#2a2a2a] text-left p-4 rounded-xl transition-colors group"
              >
                <div className="flex items-center justify-between">
                  <p className="text-gray-300 group-hover:text-white transition-colors">{popularPrompt}</p>
                  <ChevronRight size={20} className="text-gray-600 group-hover:text-purple-500 transition-colors" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// Membership Screen
function MembershipScreen() {
  const navigate = useNavigate()
  const [selectedTier, setSelectedTier] = useState('gold')
  
  const tiers = [
    {
      id: 'silver',
      name: 'Silver',
      price: 19.99,
      color: 'from-gray-400 to-gray-600',
      borderColor: 'border-gray-400',
      bgColor: 'from-gray-900/50 to-gray-800/50',
      icon: '🥈',
      features: [
        'Unlimited character chats',
        '100 AI generations per month',
        'Priority response time',
        'Access to premium characters',
        'Ad-free experience',
        'Basic customization options'
      ]
    },
    {
      id: 'gold',
      name: 'Gold',
      price: 29.99,
      color: 'from-yellow-400 to-yellow-600',
      borderColor: 'border-yellow-400',
      bgColor: 'from-yellow-900/50 to-orange-900/50',
      icon: '🥇',
      popular: true,
      features: [
        'Everything in Silver',
        '500 AI generations per month',
        'Faster response time',
        'Early access to new features',
        'Advanced customization',
        'Create custom characters',
        'Priority support'
      ]
    },
    {
      id: 'platinum',
      name: 'Platinum',
      price: 39.99,
      color: 'from-purple-400 to-blue-400',
      borderColor: 'border-purple-400',
      bgColor: 'from-purple-900/50 to-blue-900/50',
      icon: '💎',
      features: [
        'Everything in Gold',
        'Unlimited AI generations',
        'Instant response time',
        'Exclusive premium models',
        'Full customization suite',
        'Multi-character scenarios',
        'Dedicated support',
        'Beta features access'
      ]
    }
  ]
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900/20 to-black text-white pb-20 lg:pb-4">
      {/* Header */}
      <div className="sticky top-0 bg-black/80 backdrop-blur-sm border-b border-gray-800 p-4 flex items-center justify-between z-10">
        <button onClick={() => navigate(-1)}>
          <ChevronRight size={24} className="rotate-180 text-white" />
        </button>
        <h1 className="text-xl font-bold">Membership Plans</h1>
        <button>
          <Settings size={24} className="text-gray-400" />
        </button>
      </div>

      <div className="p-4 max-w-6xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-3">Unlock Premium Features</h2>
          <p className="text-gray-400 text-lg">Choose the perfect plan for your AI experience</p>
        </div>

        {/* Benefits Banner */}
        <div className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-xl p-6 mb-8 border border-purple-500/30">
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Crown size={24} className="text-yellow-500" />
            Why Go Premium?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <div className="text-2xl">⚡</div>
              <div>
                <h4 className="font-semibold mb-1">Faster Responses</h4>
                <p className="text-gray-400 text-sm">Get instant AI replies without waiting</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="text-2xl">🎨</div>
              <div>
                <h4 className="font-semibold mb-1">More Generations</h4>
                <p className="text-gray-400 text-sm">Create unlimited images and videos</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="text-2xl">✨</div>
              <div>
                <h4 className="font-semibold mb-1">Exclusive Content</h4>
                <p className="text-gray-400 text-sm">Access premium characters and features</p>
              </div>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {tiers.map((tier) => (
            <div
              key={tier.id}
              className={`relative rounded-2xl p-6 border-2 transition-all cursor-pointer ${
                selectedTier === tier.id
                  ? `${tier.borderColor} scale-105`
                  : 'border-gray-800 hover:border-gray-700'
              } bg-gradient-to-br ${tier.bgColor}`}
              onClick={() => setSelectedTier(tier.id)}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                    MOST POPULAR
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <div className="text-5xl mb-3">{tier.icon}</div>
                <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-bold">${tier.price}</span>
                  <span className="text-gray-400">/month</span>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {tier.features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="text-green-500 mt-1">✓</div>
                    <span className="text-gray-300 text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                className={`w-full py-3 rounded-xl font-semibold transition-all ${
                  selectedTier === tier.id
                    ? `bg-gradient-to-r ${tier.color} text-white`
                    : 'bg-[#1a1a1a] text-gray-400 hover:bg-[#2a2a2a]'
                }`}
              >
                {selectedTier === tier.id ? 'Selected' : 'Select Plan'}
              </button>
            </div>
          ))}
        </div>

        {/* Subscribe Button */}
        <div className="max-w-md mx-auto mb-8">
          <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-4 rounded-xl transition-all transform hover:scale-[1.02] flex items-center justify-center gap-2">
            <Crown size={24} />
            <span>Subscribe to {tiers.find(t => t.id === selectedTier)?.name} - ${tiers.find(t => t.id === selectedTier)?.price}/mo</span>
          </button>
        </div>

        {/* Comparison Table */}
        <div className="bg-[#1a1a1a] rounded-xl p-6 mb-8">
          <h3 className="text-xl font-bold mb-4">Feature Comparison</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-3 px-4 text-gray-400 font-semibold">Feature</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-semibold">Silver</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-semibold">Gold</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-semibold">Platinum</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-800">
                  <td className="py-3 px-4 text-gray-300">AI Generations</td>
                  <td className="text-center py-3 px-4">100/mo</td>
                  <td className="text-center py-3 px-4">500/mo</td>
                  <td className="text-center py-3 px-4 text-green-500 font-semibold">Unlimited</td>
                </tr>
                <tr className="border-b border-gray-800">
                  <td className="py-3 px-4 text-gray-300">Response Time</td>
                  <td className="text-center py-3 px-4">Priority</td>
                  <td className="text-center py-3 px-4">Faster</td>
                  <td className="text-center py-3 px-4 text-green-500 font-semibold">Instant</td>
                </tr>
                <tr className="border-b border-gray-800">
                  <td className="py-3 px-4 text-gray-300">Premium Characters</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                </tr>
                <tr className="border-b border-gray-800">
                  <td className="py-3 px-4 text-gray-300">Custom Characters</td>
                  <td className="text-center py-3 px-4 text-red-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                </tr>
                <tr className="border-b border-gray-800">
                  <td className="py-3 px-4 text-gray-300">Multi-Character Scenarios</td>
                  <td className="text-center py-3 px-4 text-red-500">✗</td>
                  <td className="text-center py-3 px-4 text-red-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-gray-300">Beta Features</td>
                  <td className="text-center py-3 px-4 text-red-500">✗</td>
                  <td className="text-center py-3 px-4 text-red-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-500">✓</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-[#1a1a1a] rounded-xl p-6">
          <h3 className="text-xl font-bold mb-4">Frequently Asked Questions</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 text-purple-400">Can I cancel anytime?</h4>
              <p className="text-gray-400 text-sm">Yes, you can cancel your subscription at any time. Your benefits will continue until the end of your billing period.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-purple-400">Can I upgrade or downgrade?</h4>
              <p className="text-gray-400 text-sm">Absolutely! You can change your plan at any time. Upgrades take effect immediately, while downgrades apply at the next billing cycle.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-purple-400">What payment methods do you accept?</h4>
              <p className="text-gray-400 text-sm">We accept all major credit cards, PayPal, and various digital payment methods.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <p className="mb-2">By subscribing, you agree to our <a href="#" className="text-purple-400">Terms of Service</a> and <a href="#" className="text-purple-400">Privacy Policy</a></p>
          <p>All prices in USD. Billed monthly. Cancel anytime.</p>
        </div>
      </div>
    </div>
  )
}

// Placeholder screens for other routes
function PlaceholderScreen({ title }) {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center pb-20 lg:pb-4">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">{title}</h1>
        <p className="text-gray-400 mb-6">This screen is under construction</p>
        <Button onClick={() => navigate('/')} className="bg-purple-600 hover:bg-purple-700">
          Go Home
        </Button>
      </div>
    </div>
  )
}

// Main App Component with Router
function AppContent() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()

  return (
    <div className="flex min-h-screen bg-black">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Main Content */}
      <div className="flex-1 lg:ml-72">
        {/* Mobile Menu Button */}
        <button
          onClick={() => setSidebarOpen(true)}
          className="fixed top-4 left-4 z-30 lg:hidden bg-[#1a1a1a] p-2 rounded-lg"
        >
          <Menu size={24} className="text-white" />
        </button>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<ChatListScreen />} />
          <Route path="/messages" element={<ChatListScreen />} />
          <Route path="/explore" element={<ExploreScreen />} />
          <Route path="/character/:id" element={<CharacterProfileScreen />} />
          <Route path="/chat/:id" element={<ChatScreen />} />
          <Route path="/create" element={<CreateScreen />} />
          <Route path="/generate" element={<GenerateScreen />} />
          <Route path="/coins" element={<CoinsScreen />} />
          <Route path="/profile" element={<PlaceholderScreen title="Profile" />} />
          <Route path="/following" element={<PlaceholderScreen title="Following" />} />
          <Route path="/top-creators" element={<PlaceholderScreen title="Top Creators" />} />
          <Route path="/you" element={<PlaceholderScreen title="You" />} />
          <Route path="/for-you" element={<PlaceholderScreen title="For You" />} />
          <Route path="/characters" element={<PlaceholderScreen title="Characters" />} />
          <Route path="/gallery" element={<PlaceholderScreen title="Gallery" />} />
          <Route path="/favorites" element={<PlaceholderScreen title="Favorites" />} />
          <Route path="/membership" element={<MembershipScreen />} />
          <Route path="/install" element={<PlaceholderScreen title="Install App" />} />
        </Routes>

        {/* Bottom Navigation */}
        <BottomNav />
      </div>
    </div>
  )
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  )
}

export default App

